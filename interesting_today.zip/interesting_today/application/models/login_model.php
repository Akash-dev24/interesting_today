<?php
class Login_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Ensure the database is loaded
    }

    // Method to insert activity
    public function insert_activity($data)
    {
        return $this->db->insert('user', $data);
    }
}
