<?php
class Activity_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); 
    }

    public function data_table($format,$table_name, $field = array() ,$condition = array(),$offset = "",$limit = "",$order_by = "",$order_by_type="")  
    {

        $data = array();
        if($format == 'Insert')
        {
            $this->db->insert($table_name,$field);
            $data['status'] = true;
            $data['last_inserted'] = $this->db->insert_id();
        }

        if($format == 'update')
        {
            $this->db->where($condition);
            $this->db->update($table_name,$field);
            $data['status'] = true;
            $data['last_inserted'] = $this->db->insert_id();
        }

        if($format == 'select')
        {
            if(count($field) > 0)
            {
                $this->db->select($field);
            }
            else
            {
                $this->db->select('*');
            }
            
            if($offset != "" && $limit != "")
            {
                $this->db->limit($offset,$limit);
            }
            else if($limit != "")
            {
                $this->db->limit($limit);
            }

            if($order_by != "" && $order_by_type != "")
            {
                $this->db->order_by($order_by, $order_by_type);
            }
            else if($order_by != "")
            {
                $this->db->order_by($order_by, "ASC");
            }
            if(count($condition) > 0)
            {
                $this->db->where($condition);
            }
            
            $query = $this->db->get($table_name);
            $data['status'] = true;
            $data['data'] = $query->result_array();
        }

        if($format == 'delete')
        {
            $this->db->where($condition);
            $this->db->delete($table_name);
            $data['status'] = true;
        }

        return $data;
    }
    
    public function insert_activity($data)
    {
        return $this->db->insert('activity', $data);
    }

    function data_table_record()
    {
        $data['record_data'] = $this->db->query('select *,u.id as a_id from activity as u join user as a on a.id = u.u_id order by u.id asc limit 100')->result_array();    
        //print_r($data['record_data']);
        $ifd = array_column($data['record_data'],'a_id');
        //print_r($ifd); die;
        $data['record'] = $this->db->query("select a_id, u_id, count(a_id) as acount from activity_like_cmt where a_id in (".implode(',',$ifd).") group by a_id ")->result_array();
        // echo"<pre>";   print_r($data['record']); die;
        $data['record_like'] = $this->db->query("select * from activity_like_cmt")->result_array();
        $data['comment'] = $this->db->query("select * from comment")->result_array();
    //   echo"<pre>";   print_r($data['record_like']); die;
        // $data['like_count']=$this->db->query()
        return $data;
    }

    public function update_like() {
        $post = $this->input->post();
        $condition = array('a_id' => $post['a_id'], 'u_id' => $this->session->userdata('user_id'));
        $existing_like = $this->data_table('select', 'activity_like_cmt', array(), $condition);
        // print_r($existing_like); die;
        if (count($existing_like['data']) > 0) 
        {
            $current_count = $existing_like['data'][0]['origin'];
            $this->data_table('delete', 'activity_like_cmt', array(), $condition);
            
        } 
        else 
        {
            $field = array('a_id' => $post['a_id'], 'u_id' => $this->session->userdata('user_id'), 'like_count' => $post['like']);
            $this->data_table('Insert', 'activity_like_cmt', $field);

        }

        return $this->db->affected_rows() > 0;
    }

    // Method to get the current like count
    public function get_like_count($u_id, $a_id) {
        $condition = array('a_id' => $a_id, 'u_id' => $u_id);
        $result = $this->data_table('select', 'activity_like_cmt', array('like_count'), $condition);
        
        if ($result['status'] && !empty($result['data'])) {
            return $result['data'][0]['like_count'];
        } else {
            return 0; // Default count if no record found
        }
    }

}
