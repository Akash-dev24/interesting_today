<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <style>
        body {
            background-color: #f5f5f5;
            font-family: sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-form {
            background-color: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .links {
            text-align: center;
            margin-top: 20px;
        }

        ;
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <div class="container">
        <div>


            <div class="login-form" id="loginForm" onsubmit="return false">
                <h2>Login Page</h2>
                <form id="login-form">
                    <label for="email">Email:</label>
                    <input type="email" id="email" placeholder="Enter your Email" required>

                    <label for="password">Password:</label>
                    <input type="password" id="password" placeholder="Enter your password" required>
                    <div id="flash-message_login" style="display: none;"></div>
                    <button type="submit" >Login</button>

                    <div class="links">
                        <a href="javascript::" onclick="showSignupForm()">Sign Up</a>
                    </div>
                </form>
            </div>

            <div class="login-form" id="signupForm" style="display: none;">
                <h2>Sign Up Page</h2>
                <form id="signup-form" onsubmit="return false">

                    <label for="signup_name">Username:</label>
                    <input type="text" id="signup_name" placeholder="Enter your username" required>

                    <label for="signup_email">Email:</label>
                    <input type="text" id="signup_email" placeholder="Enter your Email" required>

                    <label for="signup_password">Password:</label>
                    <input type="password" id="signup_password" placeholder="Enter your password" required>

                    <label for="signup_confirm_password">Confirm Password:</label>
                    <input type="password" id="signup_confirm_password" placeholder="Re-enter your password" required>
                    <div id="flash-message_sign_up" style="display: none;"></div>
                    <button type="submit" id="check-form">Sign Up</button>

                    <div class="links">
                        <a href="javascript::" onclick="showLoginForm()">Login</a>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <!-- <div class="container" id="signupForm" style="display: none;">
   
  </div> -->
    <script>
        function showFlashMessage(message, type) {
            var $flashMessage = $('#flash-message_sign_up');

            $flashMessage.removeClass('success error');

            if (type === 'error') {
                $flashMessage.addClass('error');
            } else {
                $flashMessage.addClass('success');
            }

            // Set message and show
            $flashMessage.html(`
      ${message}
      
    `);
            $flashMessage.fadeIn().delay(3000).fadeOut(); // Show message for 3 seconds
        }

        function showSignupForm() {
            $('#loginForm').hide();
            $('#signupForm').show();
        }

        function showLoginForm() {
            $('#signupForm').hide();
            $('#loginForm').show();
        }

        $(document).ready(function() {
            

            $('#signup-form').submit(function() {

                var name = $('#signup_name').val();
                var email = $('#signup_email').val();
                var password = $('#signup_password').val();
                var confirmPassword = $('#signup_confirm_password').val();


                if (password.length < 8) {

                    showFlashMessage('Mininum 8 charactor for password', 'error');
                    return false;
                }

                if (confirmPassword.length < 8) {

                    showFlashMessage('Mininum 8 charactor for confirm password', 'error');
                    return false;
                }

                if (password !== confirmPassword) {
                    showFlashMessage('Passwords do not match!', 'error');
                    return false;
                }



                $.ajax({
                    type: 'POST',
                    url: '<?php echo site_url('login/add_user'); ?>',
                    data: {
                        name: name,
                        email: email,
                        password: password
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log(response.status);
                        if (response.status == true) {
                            showFlashMessage(response.msg, 'success');
                            window.location.href = response.redirect;

                        }

                        if (response.status == false) {
                            showFlashMessage(response.msg, 'error');
                        }
                    }
                });
            });

            $('#login-form').submit(function() {

                var email = $('#email').val();
                var password = $('#password').val();
                

                if (password.length < 8) {

                    alert('Mininum 8 charactor for password');
                    return false;
                }



                $.ajax({
                    type: 'POST',
                    url: '<?php echo site_url('login/check_user'); ?>',
                    data: {
                        email: email,
                        password: password
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log(response.status);
                        if (response.status == true) {
                           
                            window.location.href = response.redirect;

                        }

                        if (response.status == false) {
                          alert('Please check Email and Password ');
                        }
                    }
                });
            });

        });
    </script>
</body>

</html>