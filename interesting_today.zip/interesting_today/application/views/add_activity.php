<!DOCTYPE html>
<html>
<style>
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 4px;
        font-size: 16px;
    }

    /* Success message style */
    .alert-success {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
    }

    /* Error message style */
    .alert-danger {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
    }

    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 800px;
        margin: 40px auto;
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ddd;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-control {
        width: 100%;
        height: 40px;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
    }

    .btn {
        padding: 10px 20px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
        background-color: #337ab7;
        color: #fff;
        cursor: pointer;
    }

    .btn:hover {
        background-color: #23527c;
    }

    .cke {
        border: 1px solid #ccc;
        padding: 10px;
    }

    .cke_inner {
        padding: 10px;
    }

    .cke_top {
        background-color: #f0f0f0;
        border-bottom: 1px solid #ccc;
        padding: 10px;
    }

    .cke_bottom {
        background-color: #f0f0f0;
        border-top: 1px solid #ccc;
        padding: 10px;
    }
</style>

<head>
    <title>CKEditor Form</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="container">
        <h2>Description</h2>
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php endif; ?>
        <form action="<?php echo base_url('index.php/add_activity/insert_activity') ?>" method="POST" autocomplete="off">
            <div class="form-group">
                <textarea id="description" name="description" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            toolbar: 'Basic',
            width: '100%',
            height: 300,
            uiColor: '#f0f0f0'
        });
    </script>
</body>

</html>