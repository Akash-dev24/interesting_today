<?php
$this->load->view('header');
?>
<style>
  body {
    font-family: sans-serif;
  }

  .card {
    background-color: #f2f2f2;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 20px;
  }

  .card-header {
    display: flex;
    align-items: center;
  }

  .card-header .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #4CAF50;
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 17px;
    margin-right: 10px;
  }

  .card-header .name {
    font-size: 17px;
    font-weight: bold;
  }

  .card-content {
    margin-top: 10px;
    color: #f06844;
    font-weight: 600;
    font-family: inherit;
  }

  .card-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 10px;
  }

  .card-actions .heart {
    display: flex;
    align-items: center;
    font-size: 17px;
  }

  .card-actions .comments {
    display: flex;
    align-items: center;
    font-size: 17px;
  }

  .post {
    right: 16px;
    color: #f06844;
    font-weight: 600;
    font-family: inherit;
  }

  .active {
    color: red !important;
  }

  .button-container {
    text-align: center;
  }

  .button {
    display: inline-block;
    padding: 10px 20px;
    margin: 10px;
    text-decoration: none;
    color: #fff;
    background-color: #007bff;
    border-radius: 5px;
    font-size: 16px;
    transition: background-color 0.3s ease;
  }
  #cmd_txt
  {
    border: none;
    background: #f2f2f2;
    border-bottom: 1px solid red;
  }

  #cmd_txt:hover
  {
    border: 0px solid #f2f2f2;
    background: #f2f2f2;
    border-bottom: 1px solid red;
  }
  .bg-dark {
    background-color: #f2f2f2 !important;
}
</style>

<div class="button-container">
  <a href="<?php echo site_url('add_activity/add_activity') ?>" class="button">Go to Add Activity</a>

  <?php if ($this->session->userdata('user_id') == false) { ?>
    <a href="<?php echo site_url('login/index') ?>" class="button">Login</a>
  <?php } else { ?>
    <a href="<?php echo site_url('login/logout') ?>" class="button">Logout</a>
  <?php } ?>
</div>
<div class="container">
  <?php if (count($record_data) > 0) {
    
    foreach ($record_data as $key => $value) {
      //echo"<pre>"; print_r($record_like);exit;
      $likes=0;
      $actives='';
      foreach($record_like as $key_like => $like){
        if(isset($_SESSION['user_id']) && !empty($_SESSION['user_id']))
        {
            $uses_id=$_SESSION['user_id'];
        }
        else{
          $uses_id = 0;
        }
        
        
       
        if ($value['a_id']==$like['a_id']) {
          
          $likes+=$like['like_count'];
          if ($uses_id==$like['u_id']) {

            $actives='active';
            
          }
         
        }
       
       
      }
      $comments=array();
      foreach ($comment as $key_c => $value_c) {
       
        if ($value['a_id']==$value_c['a_id']) {
            $comments[]=$value_c['cmd'];         
        }
      }
      // echo"<pre>"; print_r(count($comments));exit;
      

  ?>
      <div class="col-md-12 card">
        <div class="col-md-12 card-header">
          <div class="avatar"><?= $value['name'][0]; ?></div>
          <div class="name"><?= $value['name']; ?></div>
        </div>
        <div class="col-md-12 card-content"><?= $value['description']; ?>
        </div>
        <div class="col-md-12 card-actions">

        <?php 
        $date1 = new DateTime(date('y-m-d h:i:s',strtotime($value['created_date'])));
        $date2 = new DateTime(date('y-m-d h:i:s' ));
        // print_r($date1);
        // print_r($date2);
        $interval = $date1->diff($date2);

       
     
        ?>
          <div class="col-md-8 post">
            Posted on <?php echo $interval->d."days"." ".$interval->h."hours"  ?>
          </div>
          <div class="col-md-1 post comments">
            <a href="javascript::" class="like"><i class="fa fa-heart <?=$actives?>" data-u_id="<?= $value['u_id'] ?>" data-a_id="<?= $value['a_id'] ?>" aria-hidden="true" style="color:#7b7bf2;font-size: 19px;width:100%"><?=$likes?></i></a>

          </div>
          <div class="col-md-3 post comments">
            <a href="javascript::" class="navbar-toggler" data-toggle="collapse" data-target="#comment-<?= $value['a_id'] ?>" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
              <i class="fa fa-comment" aria-hidden="true" class="active" style="color:#7b7bf2;font-size: 20px;"><?php print_r(count($comments))?> comments</i>
            </a>

          </div>
        </div>
        <div class="pos-f-t">
          <div class="collapse" id="comment-<?= $value['a_id'] ?>">
            <div class="bg-dark p-4">
              <form method="post" action="/interesting_today/index.php/record/save_cmd">
                <input type="text" class="cmd_txt" id="cmd_txt" name="cmd" placeholder="Enter your command!..">
                <input type="hidden" name="u_id" value="<?= $value['u_id'] ?>">
                <input type="hidden" name="a_id" value="<?= $value['a_id'] ?>">
                <a href=""><button style="border: none;">Cancel</button></a>
                <button type="submit" style="border: none;">Command</button>
              </form>
              <?php foreach ($comments as $key_co => $value_co) {?>
                <p><?=$value_co?></p>

              <?php  } ?>
              
            </div>
          </div>
        </div>
      </div>
  <?php }
  } ?>




</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<?php if ($this->session->userdata('user_id')) { ?>
  <script>
    $('.like .fa-heart').on("click", function() {
      var txt = $(this).html();
      if ($(this).hasClass('active')) {
        $(this).removeClass('active');
        $(this).text((parseInt(txt) - parseInt(1)));
        var active = 0;
      } else {
        var active = 1;
        $(this).addClass('active');
        $(this).text((parseInt(txt) + parseInt(1)));
      }

      var a_id = $(this).data("a_id");
      var u_id = $(this).data("u_id");

      $.ajax({
        url: '<?php echo site_url('add_activity/update_like'); ?>',
        type: 'POST',
        dataType: 'json',
        data: {
          u_id: u_id,
          a_id: a_id,
          like: active 
        },
        success: function(response) {
          // console.log(response);
          // if (response.success == true) {
          //   if(active == 1)
          // {
          //   alert('Updated successfully ...!');
          // }
          // else
          // {
          //   alert('Removed successfully ...!');
          // }
          // } 
          // else 
          // {
          //   alert('Error updating like count');
          // }
        },
        error: function(xhr, status, error) {
          console.error('AJAX request failed: ', status, error); // Log for debugging
          alert('AJAX request failed');
        }
      });

    });
  </script>
<?php }else{ ?>
  <script>
    $('.like .fa-heart').on("click", function() {
       alert("Please Login");     
    });
  </script>
<?php } ?>

