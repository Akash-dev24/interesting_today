<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Record extends CI_Controller
{
    public function index()
    {
        $record= array();
        $record = $this->activity_model->data_table_record();
    //    echo"<pre>"; print_r($record);exit;
        $this->load->view('index',$record);
    }

    public function save_cmd()
    {
        $post_data = $this->input->post();
        $record = $this->activity_model->data_table('Insert','comment',$_POST);
        redirect('record/index');

    }
}
