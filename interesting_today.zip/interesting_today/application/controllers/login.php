<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
   
    }

    public function index()
    {
        $this->load->view('login');
    }

    public function logout()
    {
        // $this->load->view('login');
        $this->session->unset_userdata('user_id');
        redirect('record/index');
    }

    public function add_user(){

        $data = $this->input->post();

        $insert_id = $this->activity_model->data_table("Insert","user",$data);
        if($insert_id['status'] == true){
         
            
            $this->session->set_userdata("user_id",$insert_id['last_inserted']);
            $echo['status'] = true;
            $echo['msg'] = $data['name'].', Your successfully Registred!';
            $echo['redirect' ] = site_url('record/index');
        }else{

          
            $echo['status'] = false;
            $echo['msg'] = 'Sorry, Please try again...! ';
            $echo['redirect' ] = site_url('login/index');

        }
     echo json_encode($echo);

    }


    public function check_user(){

        $data = $this->input->post();

        $insert_id = $this->activity_model->data_table("select","user",array(),$data);
        // print_r($insert_id);exit;
        if($insert_id['status'] == true && isset($insert_id['data'][0])){
         
            
            $this->session->set_userdata("user_id",$insert_id['data'][0]['id']);
            $echo['status'] = true;
            $echo['msg'] = $insert_id['data'][0]['name'].', Your successfully login!';
            $echo['redirect' ] = site_url('record/index');
        }else{

          
            $echo['status'] = false;
            $echo['msg'] = 'Sorry, pleace check your email and password...! ';
            $echo['redirect' ] = site_url('login/index');

        }
     echo json_encode($echo);

    }


}
