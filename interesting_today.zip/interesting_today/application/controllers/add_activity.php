<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Add_activity extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        
       
    }

    public function index()
    {
        $this->load->view('add_activity');
    }

    public function add_activity()
    {
        $this->load->view('add_activity');
    }

    public function insert_activity()
    {
        $data = array('description' => $_POST['description'],'u_id'=>$this->session->userdata('user_id'));

        $insert = $this->activity_model->insert_activity($data);

        if ($insert) {

            $this->session->set_flashdata('success', 'Your activity has been saved successfully!');
        } else {

            $this->session->set_flashdata('error', 'Failed to save your activity.');
        }
        redirect('add_activity/index');
       
    }

    public function update_like() {
        
       
        $a_id = $this->input->post('a_id');
        $u_id = $this->input->post('u_id');
        $like = $this->input->post('like'); // 1 for like, 0 for unlike
        $post = $this->input->post();
        $condition = array('a_id' => $post['a_id'], 'u_id' => $this->session->userdata('user_id'));
        $existing_like = $this->activity_model->data_table('select', 'activity_like_cmt', array(), $condition);
        if (count($existing_like['data']) > 0) 
        {
            $current_count = $existing_like['data'][0]['origin'];
            $this->activity_model->data_table('delete', 'activity_like_cmt', array(), $condition);
            
        } 
        else 
        {
            $field = array('a_id' => $post['a_id'], 'u_id' => $this->session->userdata('user_id'), 'like_count' => $post['like']);
            $this->activity_model->data_table('Insert', 'activity_like_cmt', $field);

        }
        // Return JSON response
        echo json_encode(array('success' => true));
    }
}
